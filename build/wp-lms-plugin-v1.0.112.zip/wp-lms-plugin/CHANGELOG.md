## Version 1.0.112 - 2025-09-18

### Added
- Version 1.0.112 release

