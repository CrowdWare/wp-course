## Version 1.0.76 - 2025-09-15

### Added
- Version 1.0.76 release

