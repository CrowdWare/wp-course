## Version 1.0.74 - 2025-09-15

### Added
- Version 1.0.74 release

