## Version 1.0.45 - 2025-09-15

### Added
- Version 1.0.45 release

