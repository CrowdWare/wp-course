## Version 1.0.54 - 2025-09-15

### Added
- Version 1.0.54 release

