## Version 1.0.77 - 2025-09-16

### Added
- Version 1.0.77 release

